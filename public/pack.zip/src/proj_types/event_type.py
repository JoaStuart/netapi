from enum import Enum


class EventType(Enum):
    SHUTDOWN = 1
    SUNSET = 2
